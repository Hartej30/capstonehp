let menu = document.querySelector('.header .menu');

document.querySelector('#menu-btn').onclick = () => {
    menu.classList.toggle('active');
};

window.onscroll = () => {
    menu.classList.remove('active');
};

document.querySelectorAll('input[type="number"]').forEach(inputNumber => {
    inputNumber.oninput = () => {
        if (inputNumber.value.length > inputNumber.maxLength){
 inputNumber.value = inputNumber.value.slice(0, inputNumber.maxLength);}
    };
});

document.querySelectorAll('.view-property .details .thumb .small-images img').forEach(images => {
    images.onclick = () => {
        src = images.getAttribute('src');
        document.querySelector('.view-property .details .thumb .big-image img').src = src;
    };
});

document.querySelectorAll('.faq .box-container .box h3').forEach(headings => {
    headings.onclick = () => {
        headings.parentElement.classList.toggle('active');
    };
});

function showPopup(type) {
    hideAllPopups();
    clearFields();
    document.getElementById(type + '-popup').style.display = 'flex';
    document.querySelector('.login-container').style.display = 'none';
}

function hidePopup(type) {
    clearFields();
    document.getElementById(type + '-popup').style.display = 'none';
    if (!document.querySelector('.popup:visible')) {
        document.querySelector('.login-container').style.display = 'block';
    }
}
// Hide all popups
function hideAllPopups() {
    document.querySelectorAll('.popup').forEach(popup => popup.style.display = 'none');
}

// Clear fields in the specific popup
function clearFields(type) {
    const popup = document.getElementById(type + '-popup');
    if (popup) {
        popup.querySelectorAll('input').forEach(input => input.value = '');
        popup.querySelectorAll('.error-message').forEach(error => error.style.display = 'none');
        popup.querySelectorAll('.success-message').forEach(success => success.style.display = 'none');
    }
    // Clear login container fields if no type specified
    if (!type) {
        document.querySelectorAll('input').forEach(input => input.value = '');
    }
}
function validatePassword(password) {
    const requirements = {
        length: password.length >= 8,
        lettersAndNumbers: /[a-zA-Z]/.test(password) && /[0-9]/.test(password),
        specialCharacter: /[!@#$%^&*(),.?":{}|<>]/.test(password),
        lowerAndUpper: /[a-z]/.test(password) && /[A-Z]/.test(password)
    };

    return Object.values(requirements).every(value => value);
}

function validateSignIn(event) {
  event.preventDefault();
  const email = document.getElementById('signin-email')?.value || document.getElementById('signin-popup-email')?.value;
  const password = document.getElementById('signin-password')?.value || document.getElementById('signin-popup-password')?.value;
  const errorMessage = document.getElementById('signin-error') || document.getElementById('signin-popup-error');
  const successMessage = document.getElementById('signin-success') || document.getElementById('signin-popup-success');

  const users = JSON.parse(localStorage.getItem('users')) || [];

  const user = users.find(user => user.email === email && user.password === password);

  if (user) {
    successMessage.style.display = 'block';
    successMessage.textContent = "Login successful! Redirecting...";
    setTimeout(() => {
      clearFields(); // Clear the fields
      window.location.href = 'home.html'; // Redirect to home page
    }, 2000);
  } else {
    errorMessage.style.display = 'block';
    errorMessage.textContent = "Invalid email or password";
  }
}

function submitSignUp(event) {
    event.preventDefault();
    const username = document.getElementById('signup-username')?.value || document.getElementById('signup-popup-username')?.value;
    const email = document.getElementById('signup-email')?.value || document.getElementById('signup-popup-email')?.value;
    const password = document.getElementById('signup-password')?.value || document.getElementById('signup-popup-password')?.value;
    const confirmPassword = document.getElementById('signup-confirm-password')?.value || document.getElementById('signup-popup-confirm-password')?.value;
    const isLandlord = document.getElementById('is-landlord')?.checked || document.getElementById('is-popup-landlord')?.checked;
    const errorMessage = document.getElementById('signup-error') || document.getElementById('signup-popup-error');
    const successMessage = document.getElementById('signup-success') || document.getElementById('signup-popup-success');

    if (password !== confirmPassword) {
        errorMessage.style.display = 'block';
        errorMessage.textContent = "Passwords do not match";
        return;
    }

    if (!validatePassword(password)) {
        errorMessage.style.display = 'block';
        errorMessage.textContent = "Password does not meet the requirements";
        return;
    }

    const users = JSON.parse(localStorage.getItem('users')) || [];

    if (users.some(user => user.email === email)) {
        errorMessage.style.display = 'block';
        errorMessage.textContent = "Email is already registered";
        return;
    }

    users.push({ username, email, password, isLandlord });
    localStorage.setItem('users', JSON.stringify(users));

    errorMessage.style.display = 'none';
    successMessage.style.display = 'block';
    successMessage.textContent = "Sign up successful! Please sign in.";

    setTimeout(() => {
        clearFields(); // Clear the fields
        successMessage.style.display = 'none';
        hidePopup('signup'); // Hide the signup popup
        showPopup('signin'); // Show the signin popup
    }, 2000);
}

function googleSignIn() {
    alert("Google Sign-In is not set up.");
}

// Image slider functionality for listings page
document.addEventListener('DOMContentLoaded', function() {
    const sliders = document.querySelectorAll('.slider');
    
    sliders.forEach(slider => {
        let currentIndex = 0;
        const images = slider.querySelectorAll('img');
        
        function showImage(index) {
            images.forEach((img, i) => {
                img.style.display = i === index ? 'block' : 'none';
            });
        }
        
        showImage(currentIndex);
        
        setInterval(() => {
            currentIndex = (currentIndex + 1) % images.length;
            showImage(currentIndex);
        }, 3000);
    });

    const modal = document.getElementById('image-modal');
    const modalImg = modal.querySelector('#modal-img');
    let currentImages = [];

    sliders.forEach(slider => {
        const images = slider.querySelectorAll('img');
        images.forEach(img => {
            img.addEventListener('click', function() {
                currentImages = Array.from(images);
                modalImg.src = this.src;
                modal.style.display = 'block';
                currentIndex = currentImages.indexOf(this);
            });
        });
    });

    const prev = document.querySelector('.prev');
    const next = document.querySelector('.next');

    prev.addEventListener('click', function() {
        currentIndex = (currentIndex > 0) ? currentIndex - 1 : currentImages.length - 1;
        modalImg.src = currentImages[currentIndex].src;
    });

    next.addEventListener('click', function() {
        currentIndex = (currentIndex + 1) % currentImages.length;
        modalImg.src = currentImages[currentIndex].src;
    });

    document.querySelector('.close').addEventListener('click', function() {
        modal.style.display = 'none';
    });
});

// Calculate price function
function calculatePrice() {
    var sqft_living = document.getElementsByName('sqft_living')[0].value;
    var sqft_lot = document.getElementsByName('sqft_lot')[0].value;
    var price_per_sqft = document.getElementsByName('price_per_sqft')[0].value;

    if (sqft_living && price_per_sqft) {
        var price = sqft_living * price_per_sqft;
        document.getElementById('calculated-price').innerText = 'Calculated Price: $' + price.toLocaleString();
    } else {
        document.getElementById('calculated-price').innerText = 'Please fill in all required fields';
    }
}

// Add min and max value enforcement for number inputs
document.querySelectorAll('input[type="number"]').forEach(inputNumber => {
    inputNumber.addEventListener('input', () => {
        let min = parseFloat(inputNumber.min);
        let max = parseFloat(inputNumber.max);
        let value = parseFloat(inputNumber.value);

        if (value < min) inputNumber.value = min;
        if (value > max) inputNumber.value = max;
    });
});

function addProperty() {
    alert("Property has been added successfully!");
}

// Populate email field based on selected agent
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const agentEmail = urlParams.get('agentEmail');
    if (agentEmail) {
        document.getElementById('agent-email').value = agentEmail;
    }
});

// Adjust the initial position of the login container
document.addEventListener('DOMContentLoaded', function() {
    const loginContainer = document.querySelector('.login-container');
    if (loginContainer) {
        loginContainer.style.marginTop = '120px';
    }
});
