<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $number = htmlspecialchars($_POST['number']);
    $message = htmlspecialchars($_POST['message']);
    $agentEmail = htmlspecialchars($_POST['agentEmail']);

    // Email subject and body
    $subject = "New Message from $name";
    $body = "Name: $name\nEmail: $email\nPhone Number: $number\nMessage:\n$message";

    // Send email
    if (mail($agentEmail, $subject, $body)) {
        echo "Message sent successfully.";
    } else {
        echo "Failed to send message.";
    }
}
?>
